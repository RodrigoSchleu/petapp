import './Sidebar.css';
import logo from '../../assets/avatar.png';

const Sidebar = ({ sidebarOpen, closeSidebar }) => {
    return (
        <div className={sidebarOpen ? "sidebar-responsive" : ""} id="sidebar">
            <div id='topbar' className='topbar' style={{ marginBottom: "90px", height: "65px", padding: "10px 0 0" }}>
                <i onClick={() => closeSidebar()} className="fa-solid fa-x" id="sidebarIcon" aria-hidden="true"></i>
                <div className="sidebar__profile">
                    <div className="sidebar__img">
                        <img src={logo} alt="logo" />
                    </div>
                </div>
            </div>
            <div className='sidebar__area'>
                <div className="sidebar__menu">
                    <a href='#'>
                        <div className="sidebar__link active_menu_link">
                            <div className='text__link'>Home</div>
                        </div>
                    </a>
                    <a href='#'>
                        <div className="sidebar__link">
                            <div className='text__link'>Perfil Pet</div>
                        </div>
                    </a>
                    <a href='#'>
                        <div className="sidebar__link">
                            <div className='text__link'>Meus Serviços</div>
                        </div>
                    </a>
                    <a href='#'>
                        <div className="sidebar__link">
                            <div className='text__link'>Histórico de Serviços</div>
                        </div>
                    </a>
                </div>
            </div>
            <div className='sidebar__footer'>
                <a href='#'>
                    <div className="sidebar__link" style={{ background: "#607d8b" }}>
                        <div className='text__link'>Guia do Usuário</div>
                    </div>
                </a>
                <div className='footer__line'/>
                <a href='#'>
                    <div className='footer__button'>
                        <div className='text__link'>Sair</div>
                    </div>
                </a>
            </div>
        </div>
    );
}
export default Sidebar;